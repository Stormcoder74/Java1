package ru.geekbrains.java1.lesson_08;
// time 3:44
public class MainClass {
    public static void main(String[] args) {
        MyWindow window = new MyWindow();
    }
}
